import React from 'react';

const AdminCard = (props) => {
    return (
   <>
            <div className='p-6 w-[200px] group h-[134px] bg-white rounded-lg border hover:border-blue-700 border-gray-200 font-Poppins'>
                <h5 className='mb-2 text-base font-bold tracking-tight text-center  group-hover:text-red-400 text-[#9FA2B4]'>{props.title}</h5>
                <p className='mb-3 font-semibold text-3xl font-Poppins text-center text-gray-700  group-hover:text-red-400 dark:text-gray-400'>{props.data}</p>
            </div>
            </>
      
    );
}

export default AdminCard;
